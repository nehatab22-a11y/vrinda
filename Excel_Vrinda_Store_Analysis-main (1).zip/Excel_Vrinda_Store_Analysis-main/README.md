# Excel- Vrinda Store Data Analysis 
Data and files related to Excel tutorial videos on Rishabh Mishra's youtube channel 

## Watch videos related to data analytics project: 
https://www.youtube.com/watch?v=gTK5rNhWJyA 
